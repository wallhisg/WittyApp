# WittyApp
Witty Application

# Sublime text hotkey
change same variable name
alt+f3

# web command
http://localhost:8080/resource/?devInfo={"id":"1","ip":"192.168.1.1","name":"BTN","value":"0"}
