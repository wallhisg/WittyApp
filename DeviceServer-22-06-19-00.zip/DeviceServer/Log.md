# 22-06-14
- Khoi tao class WebEvent	=>	processWebEvent
- Khoi tao class DevEvent	=>	processDevicecEvent

