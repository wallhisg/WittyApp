#include "ServerWidget.h"

ServerWidget::ServerWidget(WVBoxLayout *parent)
	: mainLayout_(parent)
{

}

void ServerWidget::createUi()
{
	renderHeader();
	renderContent();
}

void ServerWidget::renderHeader()
{
	WImage *headerIcon_ = new Wt::WImage("resources/icons/DongA.png");
	WText *headerBanner_ = new WText(WString::tr("header.banner"));


	header_ = new TableLayout();
	header_->setStyleClass("table");
	header_->addWidget(0, 0, headerIcon_);
	header_->addWidget(0, 1, headerBanner_);

	content_ = new TableLayout();
	content_->addWidget(new WText("Content Widgets"));
	header_->addLayout(content_);

	mainLayout_->addLayout(header_->vLayout());

	header_->removeLayout(content_);

	// mainLayout_->addLayout(content_->vLayout());
}

void ServerWidget::renderContent()
{
	// content_ = new Content();

	// tbl_tr_devId_ = new WText(WString::tr("tbl.tr.devId"));
	// WText *tbl_tr_devId1_ = new WText(WString::tr("tbl.tr.devId"));
	// WText *tbl_tr_devId2_ = new WText(WString::tr("tbl.tr.devId"));
	// WText *tbl_tr_devId3_ = new WText(WString::tr("tbl.tr.devId"));

	// content_->addWidget(0, 0, tbl_tr_devId_);

	// tableLayout = new TableLayout();
	// tableLayout->addWidget(0, 0, tbl_tr_devId_);
	// tableLayout->addWidget(0, 1, tbl_tr_devId1_);
	// tableLayout->addWidget(0, 2, tbl_tr_devId2_);
	// tableLayout->addWidget(0, 3, tbl_tr_devId3_);
	// tableLayout->setStyleClassCell(0, 0, "table-dev");
	// tableLayout->setStyleClassColumn(2, "table");
	// tableLayout->setLength(0, 15);
	// tableLayout->setLength(1, 25);
	// tableLayout->setLength(2, 25);

	// mainLayout_->addLayout(content_->vLayout());
	// mainLayout_->addLayout(tableLayout->vLayout());

}