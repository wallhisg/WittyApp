#ifndef LAYOUT_H
#define LAYOUT_H

#include <Wt/WVBoxLayout>
#include <Wt/WHBoxLayout>
#include <Wt/WAnimation>

#include <TableLayout.h>

using namespace std;
using namespace Wt;

class Layout : public TableLayout
{
public:
	Layout();
	~Layout();

	void show();
	void hide();

	
private:
	WVBoxLayout  *vLayout_;
	WVBoxLayout  *blankLeft_;
	WVBoxLayout  *blankRight_;
}









#endif	//	LAYOUT_H